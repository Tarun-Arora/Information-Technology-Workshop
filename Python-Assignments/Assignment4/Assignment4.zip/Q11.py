import numpy as np
v=np.array([[0,1,2], [3,4,5]])
print('Diagonal Sum: ',np.trace(v))