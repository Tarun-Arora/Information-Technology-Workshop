import numpy as np
v = np.array([0, 30, 45, 60, 90])
print("sine:", np.sin(np.deg2rad(v)))
print("cosine:", np.cos(np.deg2rad(v)))
print("tangent:", np.tan(np.deg2rad(v)))