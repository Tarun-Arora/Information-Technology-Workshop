import numpy as np
v = np.array([1, 2, 3])
print("Size of array :", v.size)
print("Length of one array element in bytes:", v.itemsize)
print("Total bytes consumed by the elements of the array:", v.nbytes)