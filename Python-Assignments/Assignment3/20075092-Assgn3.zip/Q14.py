import os,shutil
print("My Current Working Directory: ",os.getcwd())
currdir=os.getcwd()
folder="newdir"
#Creating New Directory
new=currdir+"/"+folder
os.mkdir(new)
os.chdir(new)
# f=open("myfile.txt","x")
shutil.rmtree(new)