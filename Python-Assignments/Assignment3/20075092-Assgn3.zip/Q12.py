file=open('test.txt')
l=file.read().upper().split('\n')
print('\n'.join(l))