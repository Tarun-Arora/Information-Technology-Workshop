file=open('test.txt','r')
print(file.read())
file.close()