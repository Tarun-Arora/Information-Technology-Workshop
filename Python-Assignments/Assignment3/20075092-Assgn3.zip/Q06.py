file=open('test.txt','r')
print(len(file.read().split('\n')))
file.close()