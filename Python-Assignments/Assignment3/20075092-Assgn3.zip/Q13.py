file=open('test.txt')
l=file.read().split('\n')
for i in l:
    print(i.split())