import re
file=open('test.txt','r')
l=tuple(re.split(r'\n\n*',file.read()))
print(l)